On-line BPMN
BPMN_DORIO_Sportello Polifunzionale Definitivo.xml|Comune XYZ|Attuazione di uno sportello polifunzionale
BPMN_Diagramma.xml||
